package com.microservices.transac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionalApplicationTests {

	@Test
	void contextLoads() {
	}

}
